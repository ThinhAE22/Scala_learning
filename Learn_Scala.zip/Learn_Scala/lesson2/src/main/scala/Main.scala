//input name
import scala.io.StdIn.readLine

object Inputname extends App {
  println("What is your name?")

  val name = readLine()
  println(s"Hello $name")
}

//tuple
object Tuple extends App {
  val person = ("John", "Johnson", 32)
  // Assign names
  val (firstName, lastName, age) = person

  println(firstName) // John
  println(lastName)  // Johnson
  println(age)       // 32  
  print(s"First name: $firstName, Last name: $lastName, Age: $age years\n")
}

//string 
object Stringplay extends App {
  val s = "Programming"
  val c = s.charAt(0)
  println(c) //p
}
//Declare val var x: Int = 5

//name and formatted string
object Person extends App {
  val person = ("Lisa", "Patterson", 32)
  // Assign names
  val (firstName, lastName, age) = person

  print(s"First name: $firstName, Last name: $lastName, Age: $age years\n") 
}

//Initials
object Initials extends App {
  println("Type your firstname")
  val firstName = readLine()
  println("Type your lastname")
  val lastName = readLine()
  val fl = firstName.charAt(0)
  val ll = lastName.charAt(0)
  println(s"Your intials: $fl .$ll .")
}