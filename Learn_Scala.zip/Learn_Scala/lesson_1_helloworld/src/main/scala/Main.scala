@main def hello(): Unit =
  println("Hello world!")
  println(msg)

def msg = "I was compiled by Scala 3. :)"

object HelloScala extends App {
  // Prints Hello Scala
  println("Hello Scala")
}