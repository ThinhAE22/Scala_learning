package utils
//define scala object file
object CalcUtils {
  def calcSum(x: Int, y: Int) : Int = {
    var sum = x + y
    return sum
  }

  def calcSub(x: Int, y: Int) : Int = {
    var sub = x - y
    return sub
  }
}