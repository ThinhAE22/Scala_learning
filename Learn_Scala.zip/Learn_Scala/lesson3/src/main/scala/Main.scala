import utils.CalcUtils
//import and use
object ScalaMethods extends App {
  println("Method demonstration")
  println("5 + 6 = " + CalcUtils.calcSum(5, 6))
  println("5 - 6 = " + CalcUtils.calcSub(5, 6))
}

//index of the getPerson returned data
object HelloScala extends App {
  def getPerson = {
    val person = ("John", "Johnson", 32)
    person
  }

  val user = getPerson;
  println(user._1)
  println(user._2)
  println(user._3)
}
//High order function
object FuncExample extends App {
  //(f: (Int, Int) => Int, x: Int, y: Int) => Int a function f get 2 int and return a int
  def add(f: (Int, Int) => Int, x: Int, y: Int): Int = f(x, y)

  val sum = (x: Int, y: Int) => (x + y)
  val squareSum = (x: Int, y: Int) => (x * x + y * y)

  val s1 = add(sum, 4, 5)
  val s2 = add(squareSum, 4, 5)

  println(s1 + " " + s2)
}

//Initials method
import scala.io.StdIn.readLine

object Initials extends App {
  def printInitials(fn: String, ln: String): Unit = {
    val fl = fn.charAt(0)
    val ll = ln.charAt(0)
    println(s"$fl.$ll.")
  }
  
  printInitials("John","Smith")
}

//High order func
object Message extends App {
  // msgFunc takes a function that accepts a String and returns Unit, and a String parameter.
  def msgFunc(f: String => Unit, x: String): Unit = f(x)

  // Functions that print messages
  val helloMsg: String => Unit = (x: String) => println(s"Hello $x")
  val goodbyeMsg: String => Unit = (x: String) => println(s"Goodbye $x")

  // The name to be used
  val name: String = "Lisa"

  // Call msgFunc with helloMsg and goodbyeMsg
  msgFunc(helloMsg, name)
  msgFunc(goodbyeMsg, name)
}

//Square
import scala.io.StdIn.readInt

object Square extends App {
  // Define the square function using a function literal
  val square: Int => Int = x => x * x

  // Asking the user for an integer input
  println("Type an integer")

  // Reading user input
  val input = readInt()

  // Calculating the square of the input
  val result = square(input)

  // Printing the result
  println(s"Square = $result")
}
