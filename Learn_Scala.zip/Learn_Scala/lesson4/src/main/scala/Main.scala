object HelloScala extends App {

  def minInt(x: Int, y: Int): Unit = {
    var min = x

    if (y < x) {
      min = y
    }

    println(s"Minimum is $min")
  }

  minInt(7, 2)
}

//return method
object TestMethod extends App {

  def isValidString(x: String): Boolean = {
    if (x.length >= 5 && x.length <= 10) {
      true
    } else {
      false
    }
  }

  val test1 = isValidString("Test")
  val test2 = isValidString("SecondTest")
  println(s"$test1")
  println(s"$test2")
}
//Direction
object Direction extends App {
  def direction(x: Int): String = x match {
    case 0 => "North"
    case 1 => "West"
    case 2 => "South"
    case 3 => "East"
    case _ => "Invalid direction"
  }

  println(direction(2)) // Output: South
  println(direction(0)) // Output: North
  println(direction(7)) // Output: Invalid direction
}

import scala.io.StdIn.readInt

object Greatest extends App {
  // Function to find the greatest of three integers
  def greatest(x: Int, y: Int, z: Int): Int = {
    if (x >= y && x >= z) x
    else if (y >= x && y >= z) y
    else z
  }

  // Asking the user for three integer inputs
  println("Enter integer 1")
  val num1 = readInt()

  println("Enter integer 2")
  val num2 = readInt()

  println("Enter integer 3")
  val num3 = readInt()

  // Calculating the greatest of the three inputs
  val result = greatest(num1, num2, num3)

  // Printing the result
  println(s"Greatest = $result")
}

import scala.collection.mutable.ArrayBuffer
//Some arr method
object HelloScala1 extends App {
  val arr1 = Array(2, 6, 1, 4, 3, 7)

  println("The length of array = " + arr1.length)
  println("The largest value = " + arr1.max)
  println("The smallest value = " + arr1.min)
  println("The first element of reversed array = " + arr1.reverse(0))
  println("The sum of elements = " + arr1.sum)

  //map funct
  val nums = Array(2, 4, 8)
  val nums2 = nums.map(x => x * 2)
  // nums2 -> (4, 8, 16)

  //filter
  val nums3 = Array(2, 4, 8, 10)
  val nums4 = nums3.filter(x => x > 4)
  // nums2 -> (8, 10)

  //Buffer
  var names = new ArrayBuffer[String]()

  names += "John"
  names += "Lisa"
  names += "Mike"
}
//Set
import scala.collection.mutable.Set

object HelloScala2 extends App {
  val nums = Set(1, 2, 3)
  nums += 4  // nums = Set(1, 2, 3, 4)
  nums -= 2 // nums = Set(1, 3, 4)
}


//Map
import scala.collection.mutable.Map

object HelloScala3 extends App {
  val countries = Map("US" -> "USA", "FI" -> "Finland", "AU" -> "Australia", "BR" -> "Brazil")

  // Different ways to add new key - value pairs
  countries("CA") = "Canada"
  countries += ("BE" -> "Belgium")
  countries.put("CL", "Chile")

  // Both statements removes "AU" -> "Australia" element from map
  countries -= "AU"
  countries.remove("AU")

  // Empty map where keys are characters and values are integers
  var characters: Map[Char, Int] = Map()
  // Empty map where keys are strings and values are integers
  var words: Map[String, Int] = Map()
}


//names
import scala.io.StdIn.readLine

object SortedNames extends App {
  // Define the size of the array
  val size = 3 // for example, you can change it to any desired size

  // Create an array of strings with predefined size
  val names = new Array[String](size)

  def sortedFirstName(): String = {
    for (i <- names.indices) {
      println("Enter name")
      names(i) = readLine()
    }
    
    val sortedNames = names.sorted
    sortedNames(0)
  }

  // Get the first name in alphabetical order
  val firstName = sortedFirstName()

  // Print the result
  println(s"The first in alphabetical order is: $firstName")
}


//Even number
object EvenNumbers extends App {
  // Create an array of integers
  val numbers = Array(1, 4, 6, 13, 16, 17, 22, 31, 33, 37)

  // Filter even numbers
  val evenNumbers = numbers.filter(_ % 2 == 0)
  // Filter odd numbers
  val oddNumbers = numbers.filter(_ % 2 != 0)

  // Print the amount of even and odd numbers
  println("The amount of even numbers is " + evenNumbers.length)
  println("The amount of odd numbers is " + oddNumbers.length)
}

//val nums = List(4 ,1 ,5 ,2 ,3)
//val nums2 = nums.sorted(Ordering.Int.reverse)
object OwnSorting extends App {
  val names = List("Elisabeth", "Mike", "Lisa", "Annie", "John", "Layla")

  // Sort the names by the second character
  val sortedNames = names.sortBy(_.charAt(1))

  // Print the sorted list
  print("List(")
  for (i <- sortedNames.indices) {
    print(sortedNames(i))
    if (i < sortedNames.length - 1) print(", ")
  }
  print(")")
}

//val country = countries("FI")
//println(country) // prints Finland

object Squares extends App {
  val numbers = Array(2, 6, 1, 4, 3, 7)
  val numbers2 = numbers.map(x => x * x)
  val sum = numbers2.sum

  print(s"The sum of squares is $sum\n")
}


//Lesson 5
//for loops
object HelloScala4 extends App {
  var x = 0

  for(x <- 1 to 5) {
    println(s"x = $x")//increment
  }
  println()
  for(x <- 5 to 1 by -1) {
    println(s"x = $x")//reverse
  }
  println()
  for(x <- 1 until 5) {
    println(s"x = $x") //not including 5
  }
}
//Nest loop
object NestedLoop extends App {
  var x = 0
  var y = 0

  for(x <- 1 to 5; y <- 2 to 4 ) {
    println(s"x = $x, y = $y")
  }

  //Another syntax
  for {
  x <- 1 to 5
  y <- 2 to 4
  } {
    println(s"x = $x, y = $y")
  }
  var text= "Hello"
  //Text itterate
  for (c <- text) {
    print(c + ",")
  }

  //Maps itterate
  val countries = Map("US" -> "USA", "FI" -> "Finland", "AU" -> "Australia", "BR" -> "Brazil")

  for ((key, value) <- countries) {
    println(s"key = $key, value = $value")
  }
  //for each loop
  val nums = List(1, 2, 3)

  nums.foreach{ println }
}

//While loop
object HelloScala5 extends App {
  var userInput = ""
  while (userInput != "end") {
    println("Type some text (Type 'end' to exit)")
    userInput= readLine()
    println(s"You typed: $userInput")
  }
}

object HelloScala6 extends App {
  var x = 0

  for(x <- 10 to 1 by -2) {
    print(s"$x ")
  }
}

object Factorial extends App {
  println("Type the integer:")
  val n = scala.io.StdIn.readInt()

  var factorial = 1
  for (i <- 1 to n) {
    factorial *= i
  }

  println(s"The factorial of $n is $factorial")
}

//yield
object Filtering extends App {
  val numbers = Array(2, 6, 1, 9, 3, 12, 21, 5, 16)

  // Create a new array using for loop with filter
  val filteredArray = for {
    num <- numbers
    if num > 6
  } yield num

  // Print values of the filtered array
  for (num <- filteredArray) {
    println(num)
  }
}


//Class

//some method
object HelloScala7 extends App {
  var student1 = new Student("John Johnson", 17)
  student1.sayHello()
}

class Student(var name: String, var age: Int = 15) {
  private def printHello(): Unit = { println(s"Hello $name") }

  def sayHello(): Unit = {
    printHello()
  }
}

//Class ex
object Company extends App {
  val employee = new Employee("Lisa Smith")
  val manager = new Manager("Mary Poppins", "12345")
  employee.paySalary(2000)
  println(employee.toString)
  manager.payBonus(500)
  println(manager.toString)
}

class Employee(val name: String) {
  def paySalary(amount: Int): Unit = {
    println(s"Salary paid: $amount")
  }

  override def toString: String = {
    s"Hello $name"
  }
}

class Manager(name: String, val managerId: String) extends Employee(name) {
  def payBonus(amount: Int): Unit = {
    println(s"Bonus paid: $amount")
  }

  override def toString: String = {
    s"Manager $managerId"
  }
}
//Pet
object PetProgram extends App {
  val cat = new Cat("Garfield")
  cat.sayHello()
  cat.eat()
  cat.sleep()
}

trait Pet {
  def sleep(): Unit = {
    println("I am sleeping")
  }

  def eat(): Unit = {
    println("I am not hungry anymore")
  }
}

class Cat(val name: String) extends Pet {
  def sayHello(): Unit = {
    println(s"Hello, my name is $name")
  }
}


//Filter cards
object CardProgram extends App {
  val cards = Array(
    new Card("Heart", 5),
    new Card("Clubs", 2),
    new Card("Spade", 9),
    new Card("Heart", 8),
    new Card("Spade", 3),
    new Card("Clubs", 4)
  )

  val filteredCards = cards.filter(_.suit == "Heart")
  filteredCards.foreach(println)
}

class Card(val suit: String, val num: Int) {
  override def toString: String = s"Card: $num $suit"
}

//Shape
object ShapeProgram extends App {
  sealed trait Shape

  case class Square(height: Int, width: Int) extends Shape
  case class Circle(radius: Int) extends Shape

  def shapeInfo(shape: Shape): Unit = {
    shape match {
      case Square(_, _) => println("This is square")
      case Circle(_) => println("This is circle")
      case _ => println("Unknown shape")
    }
  }

  val shape1 = Square(5, 2)
  val shape2 = Circle(10)
  shapeInfo(shape1)
  shapeInfo(shape2)
}


object HelloScala8 extends App {
  val myPattern = "test".r
  val str = "Now, we are testing Scala regular expressions"

  println(myPattern findFirstIn str)
  println(myPattern.findFirstIn(str))
}

object CheckPassword extends App {
  val p = "[0-9]".r
  val password = "fggGfgf6"

  p.findFirstIn(password) match {
    case Some(_) => println("Password is Ok")
    case None => println("Password should contain at least one number")
  }
}
//In this example, the valid bank account number starts 
//with two capital characters and then follows by at least
// 8 digits. The characters and digits are separated by '-' character.
object BankAccount extends App {
  val p = "[A-Z]{2}-[0-9]{8,}".r
  val bankAccount = "EG-123456789"

  if (p.matches(bankAccount)) {
    println("Account is valid")
  }
  else {
    println("Account is invalid")
  }
}

//name check
object NameCheck extends App {
  println("Enter your firstname")
  val firstName = readLine()

  val namePattern = "^[A-Z][a-z]+$".r

   if (namePattern.matches(firstName)) {
    println(s"Hello $firstName")
  }
  else {
    println("Name is invalid")
  }
}
//replace patern
object ReplaceString extends App {
  val str = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua"
  
  // Regular expression pattern to find all occurrences of "or"
  val pattern = "or".r
  
  // Replace all occurrences of "or" with "OR"
  val result = pattern.replaceAllIn(str, "OR")
  
  // Print the resulting string
  println(result)
}

//find string
object FindWords extends App {
  val str = "Dolor aute irure dolor in reprehenderit in voluptate esse cillum dolor eu fugiat nulla pariatur."

  // Regular expression pattern to find all occurrences of "dolor" or "Dolor"
  val pattern = "(?i)\\bdolor\\b".r

  // Find all matches in the string
  val matches = pattern.findAllIn(str)

  // Count the matches
  val count = matches.length

  // Print the result
  println(s"There are $count Dolor or dolor words")
}
//phone check
object PhoneCheck extends App {
  def checkNumber(phoneNumber: String): Boolean = {
    val pattern = """^\+\d{3}-\d{2}-\d{5,7}$""".r
    phoneNumber match {
      case pattern(_*) => true
      case _ => false
    }
  }

  val phoneNumbers = List(
    "+358-40-123324",
    "-358-40-123324",
    "+358-40-123789757",
    "+358-40-12A3324"
  )

  phoneNumbers.foreach(phone => println(checkNumber(phone)))
}


