package com.viope.car

class Car(var brand: String, var model: String,  var speed: Int = 0, var isOn: Boolean = false) {
  def start: Unit = {
    isOn = true
  }

  def stop: Unit = {
    speed = 0
    isOn = false
  }

  def accelerate(amount: Int): Int = {
    speed += amount
    speed
  }

  def brake(amount: Int): Int = {
    speed -= amount
    speed
  }

  override def toString: String = {
    s"Car ($brand $model) current status\n" +
    s"Speed: $speed\n" +
    s"Is on: $isOn\n"
  }
}