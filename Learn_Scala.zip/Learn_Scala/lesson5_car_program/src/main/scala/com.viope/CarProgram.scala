package com.viope

import  com.viope.car.Car

object CarProgram extends App {
  var car1 = new Car("VW", "Beetle")

  print(car1.toString)

  car1.start
  car1.accelerate(50)
  print(car1.toString)

  car1.stop
  print(car1.toString)
}

object CarProgramcollection extends App {
  var car1 = new Car("VW", "Beetle")
  var car2 = new Car("Ford", "Mustang")
  var car3 = new Car("Fiat", "500")

  val cars = Array[Car](car1, car2, car3)//arr of car

  cars.foreach(car => println(car.toString))
}